export const CAR_OFFSETS = {
  rotMatrix:    { row0: 4,  row1: 20, row2: 36 },
  pos:          { x: 52,  y: 56,  z: 60  },
  linVel:       { x: 132, y: 136, z: 140 },
  angVel:       { x: 148, y: 152, z: 156 },
  linVelMirror: { x: 312, y: 316, z: 320 },
  angVelMirror: { x: 328, y: 332, z: 336 },
};

export const WASM_EXPORTS = {
  engineForceMach: "x",
  carPtr:          "z",
  cmdBufBase:      "A",
  cmdBufCount:     "B",
  wheelArrayBase:  "C", // vehicle.+144, captured each tick (mutable i32)
  frictionSlip:    "y", // m_frictionSlip applied to every wheel each tick (mutable f32)
};

// Per-wheel struct (Bullet btWheelInfo, 284-byte stride). The mod writes the
// frictionSlip global into wheel[i] + 228 for all wheels each tick, before the
// physics world-step reads it. Other tuning sits alongside it if ever needed:
//   208 maxSuspensionTravelCm  212 wheelsRadius   216 suspensionStiffness
//   220 dampingCompression     224 dampingRelax   228 frictionSlip
//   244 rollInfluence          248 maxSuspensionForce
export const WHEEL = { stride: 284, count: 4, frictionSlip: 228 };

export const STOCK = { engineForce: 4000, friction: 3 };
export const CMD_BUFFER = { capacity: 128 };