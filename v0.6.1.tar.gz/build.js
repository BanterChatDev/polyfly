// Polyfly build pipeline.
//
// Two phases run in sequence:
//   1. Tailwind CLI compiles src/api/gui/styles.css → dist/styles.css,
//      scanning .jsx/.js files for utility class usage and emitting only
//      the classes actually used.
//   2. The compiled CSS gets `:root` rewritten to `:host` (so Tailwind's
//      CSS-variable declarations work inside our shadow DOM) and is
//      written out as a JS module `dist/styles.bundle.js` that exports
//      the CSS as a default-export string.
//   3. esbuild bundles src/main.js (entry) into dist/main.bundle.js. It
//      imports dist/styles.bundle.js so the CSS string is inlined into
//      the final JS — which is the only file the manifest loads.
//
// Watch mode runs Tailwind in --watch and esbuild in context().watch().
// Tailwind's watcher will rewrite dist/styles.css whenever a .jsx file
// changes; we have an fs.watch on dist/styles.css that re-runs the rewrite
// step + re-triggers esbuild.

const esbuild = require("esbuild");
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const STYLES_IN = path.join(ROOT, "src/api/gui/styles.css");
const STYLES_OUT = path.join(ROOT, "dist/styles.css");
const STYLES_BUNDLE = path.join(ROOT, "dist/styles.bundle.js");
const JS_ENTRY = path.join(ROOT, "src/main.js");
const JS_OUT = path.join(ROOT, "dist/main.bundle.js");

const watch = process.argv.includes("--watch");

fs.mkdirSync(path.join(ROOT, "dist"), { recursive: true });

// ---------- CSS step ----------

// Run Tailwind CLI. Returns the spawned process; the watch flag controls
// whether it keeps running.
function runTailwind() {
  const args = [
    "tailwindcss",
    "-i", STYLES_IN,
    "-o", STYLES_OUT,
    "--minify",
  ];
  if (watch) args.push("--watch");
  const p = spawn("npx", args, { stdio: ["ignore", "pipe", "pipe"] });
  p.stdout.on("data", d => process.stdout.write(d));
  p.stderr.on("data", d => process.stderr.write(d));
  return p;
}

// Read dist/styles.css, rewrite `:root` → `:host`, write a JS module that
// exports the result as a default-string. Safe to run multiple times.
function bundleStyles() {
  if (!fs.existsSync(STYLES_OUT)) {
    // Tailwind hasn't produced output yet (first watch tick). Write empty.
    fs.writeFileSync(STYLES_BUNDLE, "export default '';\n");
    return;
  }
  let css = fs.readFileSync(STYLES_OUT, "utf8");
  // `(^|[^,\\s])` ensures we don't match selectors that already include :root
  // as part of a list (e.g. `:root, :host`). The lookahead avoids matching
  // `:root-something` (no such selector exists, but harmless to be careful).
  css = css.replace(/(^|[^,\s]):root(?![a-zA-Z-])/g, "$1:host");
  fs.writeFileSync(STYLES_BUNDLE, `export default ${JSON.stringify(css)};\n`);
}

// ---------- JS step ----------

async function runEsbuild() {
  const opts = {
    entryPoints: [JS_ENTRY],
    bundle: true,
    outfile: JS_OUT,
    jsx: "automatic",
    loader: { ".js": "jsx" }, // allow JSX in .js files too
    define: { "process.env.NODE_ENV": '"production"' },
    logLevel: "info",
  };
  if (watch) {
    const ctx = await esbuild.context(opts);
    await ctx.watch();
  } else {
    await esbuild.build(opts);
  }
}

// ---------- Orchestration ----------

(async () => {
  if (watch) {
    // Watch mode: keep Tailwind running; on every CSS output, re-bundle
    // styles + esbuild picks up the change automatically via file watch.
    runTailwind();
    // Initial bundle to make sure dist/styles.bundle.js exists before
    // esbuild starts watching.
    bundleStyles();
    fs.watchFile(STYLES_OUT, { interval: 250 }, () => {
      bundleStyles();
    });
    await runEsbuild();
    console.log("[build] watching for changes...");
  } else {
    // One-shot: run Tailwind to completion, then bundle styles, then esbuild.
    await new Promise((resolve, reject) => {
      const p = runTailwind();
      p.on("exit", code => code === 0 ? resolve() : reject(new Error("tailwind exited " + code)));
    });
    bundleStyles();
    await runEsbuild();
    console.log("[build] done");
  }
})().catch(e => { console.error(e); process.exit(1); });